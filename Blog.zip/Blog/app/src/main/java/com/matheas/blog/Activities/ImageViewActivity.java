package com.matheas.blog.Activities;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.matheas.blog.Data.BlogRecyclerAdapter;
import com.matheas.blog.Model.Blog;
import com.matheas.blog.R;
import com.squareup.picasso.Picasso;

import java.util.Collections;
import java.util.List;

public class ImageViewActivity extends AppCompatActivity {

    private ImageView postImagedet;
    private String user;
    private FirebaseAuth mAuth;
    private FirebaseUser mUser;
    private String imgUrl;
    private StorageReference mStorage;
    private DatabaseReference mDeleteDatabase;
    private String id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image_view);
        String title=(String) getIntent().getSerializableExtra("title");
        setTitle(title);
        mAuth= FirebaseAuth.getInstance();
        mUser=mAuth.getCurrentUser();
        mStorage= FirebaseStorage.getInstance().getReference();
        user=(String) getIntent().getSerializableExtra("user");
        mDeleteDatabase=FirebaseDatabase.getInstance().getReference().child("Blog").child("-M9ZE-hVyZ4ac5EIn3LX");

        postImagedet=(ImageView) findViewById(R.id.postImagedet);
        imgUrl= (String) getIntent().getSerializableExtra("imageUrl");
        Picasso.get().load(imgUrl).into(postImagedet);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        if(user.equals(mUser.getUid()))
        {
            getMenuInflater().inflate(R.menu.post_menu,menu);
        }
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        mDeleteDatabase.removeValue();
        Toast.makeText(ImageViewActivity.this,"Deleted Successfully !!",Toast.LENGTH_LONG).show();
        return super.onOptionsItemSelected(item);
    }

}